package com.sap.cc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
