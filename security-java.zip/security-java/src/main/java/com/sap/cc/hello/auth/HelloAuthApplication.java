package com.sap.cc.hello.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloAuthApplication.class, args);
	}

}
