package com.sap.cc.hello.auth;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloAuthController {

	@GetMapping("/welcome")
	public String getRoot(@AuthenticationPrincipal DefaultOidcUser principal) {

		String response = "<title>Welcome Page</title>";
		response += "Hello " + getUsernameFromUser(principal) + "!";
		response += "<br/>";
		response += getAuthoritiesFromUser(principal);
		response += "<br/><br/>";
		response += "Try to access the <a href='/restricted'>/restricted</a> endpoint  ";
		response += "<br/><br/>";
		response += showLogoutIfAuthenticated(principal);
		return response;
	}

	@GetMapping("/restricted")
	public String getOidcUserPrincipal(@AuthenticationPrincipal DefaultOidcUser principal) {

		String response = "<title>Restricted Page</title>";
		response += "<H1 style=\"color: red;\">Restricted Area</H1>";
		response += "Hello " + getUsernameFromUser(principal) + "!";
		response += "<br/>";
		response += getAuthoritiesFromUser(principal);
		response += "<br/><br/>";
		response += showLogoutIfAuthenticated(principal);
		return response;
	}

	private String showLogoutIfAuthenticated(DefaultOidcUser principal) {
		return principal!=null?"<a href='/logout'><button type=\"button\">Logout</button></a>":"";
	}

	private String getAuthoritiesFromUser(DefaultOidcUser principal) {
		if (principal == null) {
			return "You have no authorizations since you are not authenticated";
		}
		return "Your authorizations: " + principal.getAuthorities();

	}

	private Object getUsernameFromUser(DefaultOidcUser principal) {
		if (principal == null) {
			return "unauthenticated user";
		}
		return principal.getAttribute("first_name") + " " + principal.getAttribute("last_name");
	}

}
