package com.sap.cc.hello.auth;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String ADMIN_ROLE = "ADMIN";
    private ClientRegistrationRepository clientRegistrationRepository;

    public WebSecurityConfig(ClientRegistrationRepository clientRegistrationRepository) {
        this.clientRegistrationRepository = clientRegistrationRepository;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.oauth2Login().and().oauth2Client();
        configureLogoutBehavior(http);
        configureAuth(http);

    }

    private void configureAuth(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/welcome").permitAll()
                .antMatchers("/restricted").hasRole(ADMIN_ROLE)
                .anyRequest().authenticated();
    }

    private void configureLogoutBehavior(HttpSecurity http) throws Exception {
        OidcClientInitiatedLogoutSuccessHandler logoutSuccessHandler = new OidcClientInitiatedLogoutSuccessHandler(
                clientRegistrationRepository);
        logoutSuccessHandler.setPostLogoutRedirectUri("{baseUrl}/welcome");
        http.logout().logoutSuccessHandler(logoutSuccessHandler);
    }
}
