package com.sap.cc.hello.auth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ClientRegistrations;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;

@Configuration
public class OAuthClientConfiguration {

    private static String ISSUER_LOCATION = "https://aghtrtxzy.accounts400.ondemand.com";

    private static String REGISTRATION_ID = "sapias";
    private static String CLIENT_NAME = "SAPIAS";
    private static String CLIENT_ID = "2a30e426-b564-4313-a4a3-e3e4d6c88050";
    private static String CLIENT_SECRET = "g/CmJZ?8gTD-7PSuG/lYs_8Uq:jT=Jy";
    private static String SCOPE = "openid";

    @Bean
    public ClientRegistrationRepository getClientRegistrationRepository(){
        ClientRegistration oidClientRegistration = ClientRegistrations
                .fromIssuerLocation(ISSUER_LOCATION)
                .registrationId(REGISTRATION_ID)
                .clientName(CLIENT_NAME)
                .clientId(CLIENT_ID)
                .clientSecret(CLIENT_SECRET)
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                .scope(SCOPE)
                .build();
        return new InMemoryClientRegistrationRepository(oidClientRegistration);
    }
}
