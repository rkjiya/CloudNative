package com.sap.cc.hello.auth.sapias;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.core.user.OAuth2UserAuthority;
import org.springframework.stereotype.Service;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;

@Service
public class IasOAuth2UserService implements OAuth2UserService<OidcUserRequest, OidcUser> {

	private final OidcUserService delegate = new OidcUserService();
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	public OidcUser loadUser(OidcUserRequest userRequest) throws OAuth2AuthenticationException {
		final Set<GrantedAuthority> authorities = new HashSet<>();
		final OidcUser oidcUser = delegate.loadUser(userRequest);

		addDefaultUserAuthority(authorities, oidcUser);

		addAuthoritiesFromCustomAccessToken(userRequest, authorities, oidcUser);

		return new DefaultOidcUser(authorities, oidcUser.getIdToken(), oidcUser.getUserInfo());
	}

	private void addDefaultUserAuthority(final Set<GrantedAuthority> authorities, final OidcUser oidcUser) {
		authorities.add(new OAuth2UserAuthority(oidcUser.getAttributes()));
	}

	private void addAuthoritiesFromCustomAccessToken(OidcUserRequest userRequest,
			final Set<GrantedAuthority> authorities, final OidcUser oidcUser) {
		try {
			List<String> roles = extractRolesFromAccessToken(userRequest.getAccessToken());
			roles.forEach(role -> authorities.add(createAuthorityFromRole(oidcUser, role)));
		} catch (ParseException e) {
			logger.error("Jwt could not be parsed");
		} catch (PathNotFoundException e) {
			logger.info("AccessToken does not seem to contain client specific scopes/roles");
		}
	}

	private List<String> extractRolesFromAccessToken(OAuth2AccessToken accessToken) throws ParseException {
		List<String> roles = new ArrayList<>();
		JWT jwt = JWTParser.parse(accessToken.getTokenValue());

		Object groups = JsonPath.parse(jwt.getJWTClaimsSet().toJSONObject()).read("$.groups");
		// need to check type: if there is only one group assigned type will be
		// String, otherwise List.
		if (groups instanceof ArrayList) {
			roles.addAll((ArrayList<String>) groups);
		} else if (groups instanceof String) {
			roles.add((String) groups);
		} else {
			logger.error(
					"The 'groups' claim of JWT is of type '{}' (expecting List or String), returning empty role list",
					groups.getClass());
		}

		return roles;
	}

	private OAuth2UserAuthority createAuthorityFromRole(final OidcUser oidcUser, String role) {
		String roleName = "ROLE_" + role.toUpperCase();
		return new OAuth2UserAuthority(roleName, oidcUser.getAttributes());
	}

}
