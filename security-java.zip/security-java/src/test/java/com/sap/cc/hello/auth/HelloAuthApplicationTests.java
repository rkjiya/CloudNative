package com.sap.cc.hello.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
