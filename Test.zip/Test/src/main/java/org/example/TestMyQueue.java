package org.example;

public class TestMyQueue {

    public static void main(String[] args) {
        addOneInQueue();
//        System.out.println(myQueue.remove());
    }

    public static void addOneInQueue(){
        MyQueue myQueue = new MyQueue();
        myQueue.add("One");
        myQueue.add("two");
        myQueue.add("One");
        myQueue.add("two");
        myQueue.add("One");
        myQueue.add("two");
        myQueue.print();
//       myQueue.print();
       myQueue.remove();
        myQueue.print();
        myQueue.remove();


    }
}
