package org.example;

public class MyQueue {

    private final int SIZE = 5;
    private String[]data = new String[SIZE];

    private int currentIndex =0;

    public void add(String value){
        if(currentIndex >= SIZE){
            System.out.println("Queue is full");
            return;
        }
        data[currentIndex] = value;
        currentIndex++;
    }


    public String remove(){
        if(currentIndex <= 0){
            System.out.println("Queue is empty");
            return null;
        }
        String first = data[0];
        currentIndex--;
        reArrange(data);
        return first;
    }

    private void reArrange(String[] data) {
        // 1,2,3,4,5
       int start = 1;
       while(start < data.length){
           data[start-1] = data[start];
           start++;
       }
    }

    public void print(){
        System.out.println("Data length :"+data.length);
        for(int i =0; i<data.length; i++){
            System.out.println(data[i]);
        }
    }

    public int size(){
        return data.length;
    }
}
