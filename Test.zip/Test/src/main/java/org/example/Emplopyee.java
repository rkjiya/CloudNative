package org.example;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Emplopyee {
//sort MAP based on values in desc order, both key & value should be printed.
    private static Map<String,Integer> map = new HashMap<>();

    public  void sort(){

        map.entrySet().stream().sorted(Comparator.comparingInt(Map.Entry :: getValue));


    }

    public static void main(String[] args) {
       Map<String, Integer> data =  Map.of("a", 1, "c", 3, "b", 2);

//        data.entrySet().stream().sorted(new Comparator<Map.Entry<String, Integer>>() {
//            @Override
//            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
//                return o2.getValue().compareTo(o1.getValue());
//            }
//        });

        data.entrySet().stream().sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()));
        System.out.println(data);
    }

}
