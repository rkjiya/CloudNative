package org.example;

public class BinarySearch {



    public static int binarySearch(int []data, int value, int startIndex, int endIndex){
        // 1,2,3,4, value  =1
        if(startIndex > endIndex){
            return -1;
        }
        int mid =  startIndex + (endIndex-startIndex)/2 ;
        if(data[mid] == value){
            return  mid;
        }
        if(data[mid] > value){
            // Check first half
            startIndex = 0;
            endIndex = mid-1;
           return binarySearch(data, value, startIndex,endIndex);
        }
        else {
            startIndex = mid+1;
            endIndex = data.length-1;
            return binarySearch(data,value, startIndex, endIndex);
        }
    }

    public static void main(String[] args) {
        int data[] = {1,2,3,4};
        int val = 1;
        System.out.println(binarySearch(data,val,0,3));
    }
}
