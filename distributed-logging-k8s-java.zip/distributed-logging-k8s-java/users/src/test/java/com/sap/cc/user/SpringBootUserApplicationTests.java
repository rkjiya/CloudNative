package com.sap.cc.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
