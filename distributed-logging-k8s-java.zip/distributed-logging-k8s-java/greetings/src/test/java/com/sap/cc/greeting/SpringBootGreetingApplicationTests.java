package com.sap.cc.greeting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGreetingApplicationTests {

	@Test
	void contextLoads() {
	}

}
