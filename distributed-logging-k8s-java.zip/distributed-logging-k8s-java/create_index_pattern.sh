curl -XPOST -D- 'https://log.ingress.fun.i518303.shoot.canary.k8s-hana.ondemand.com/api/saved_objects/index-pattern' \
    -H 'kbn-xsrf: true' \
    -H 'Content-Type: application/json' \
    -d '{"attributes":{"title":"logstash-*","timeFieldName":"@timestamp"}}'
