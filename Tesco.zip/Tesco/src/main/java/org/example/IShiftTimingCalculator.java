package org.example;

import java.util.List;

public interface IShiftTimingCalculator {

    List<Shift> getMergedShifts(List<Shift> shifts);
}
