package org.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ShiftTimingCalculatorImpl implements  IShiftTimingCalculator{


    @Override
    public List<Shift> getMergedShifts(List<Shift> shifts) {
        if(shifts == null || shifts.size() == 0){
            return Collections.emptyList();
        }

        if(shifts.size() == 1){
            return shifts;
        }


        Collections.sort(shifts, new ShiftComperator());
        List<Shift> newShifts = new ArrayList<>();
        Shift s;

        for(int i=1; i<shifts.size();i++){
            if(shifts.get(0).getEndTime().compareTo(shifts.get(i).getStartTime())  == 1 ){
                s = new Shift(shifts.get(0).getStartTime(), shifts.get(i).getEndTime());
                newShifts.add(s);
            }
            else {
                s= shifts.get(i);
            }
            newShifts.add(s);

        }
        return newShifts;
    }
}
