package org.example;

import java.util.Comparator;

public class ShiftComperator implements Comparator<Shift> {
    @Override
    public int compare(Shift o1, Shift o2) {
        if(o1 == null || o2 == null){
            throw new IllegalArgumentException("Invalid Values passed...");
        }
        return o1.getStartTime().compareTo(o2.getStartTime());
    }
}
