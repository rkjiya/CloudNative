package org.example;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class Shift {

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    public Shift(LocalDateTime startTime, LocalDateTime endTime){
        this.startTime =startTime;
        this.endTime =endTime;
    }


    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Shift shift = (Shift) o;
        return startTime.equals(shift.startTime) && endTime.equals(shift.endTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(startTime, endTime);
    }

    private void  validateInputs(){
        if(this.startTime == null || endTime == null){
            throw new IllegalArgumentException("Invalid values, please provide valid starttime and endtiom");
        }
    }
}
