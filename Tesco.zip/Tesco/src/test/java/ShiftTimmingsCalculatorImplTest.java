import org.example.IShiftTimingCalculator;
import org.example.Shift;
import org.example.ShiftTimingCalculatorImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ShiftTimmingsCalculatorImplTest {

   static  IShiftTimingCalculator iShiftTimingCalculator = new ShiftTimingCalculatorImpl();
    public static void main(String[] args) {

        Shift s1 = new Shift(LocalDate.of(2023, 1, 1).atTime(8,0),
                LocalDate.of(2023, 1, 1).atTime(10,0));
        Shift s2 = new Shift(LocalDate.of(2023, 1, 1).atTime(10,0),
                LocalDate.of(2023, 1, 1).atTime(12,0));



        List<Shift> shifts = new ArrayList<>();
        shifts.add(s1);
        shifts.add(s2);

         List<Shift> result =  iShiftTimingCalculator.getMergedShifts(shifts);
        System.out.println("result: "+result);
         if(result.size() == 1){
             System.out.println("Successful..");
         }

        given3Shifts_return2();

        givenOneShift_return1Shift();

    }

    private static void given3Shifts_return2(){
        Shift s1 = new Shift(LocalDate.of(2023, 1, 1).atTime(8,0),
                LocalDate.of(2023, 1, 1).atTime(10,0));
        Shift s2 = new Shift(LocalDate.of(2023, 1, 1).atTime(10,0),
                LocalDate.of(2023, 1, 1).atTime(12,0));
        Shift s3 = new Shift(LocalDate.of(2023, 1, 1).atTime(10,0),
                LocalDate.of(2023, 1, 1).atTime(12,0));
        List<Shift> shifts = new ArrayList<>();
        shifts.add(s1);
        shifts.add(s2);
        shifts.add(s3);
        List<Shift> result =  iShiftTimingCalculator.getMergedShifts(shifts);
        if(result.size() == 2){
            System.out.println("list size is 2");
        }

        if(result.get(0).getEndTime().getHour() == 12){
            System.out.println("End time of first shift is 12");
        }

    }

    private static void givenOneShift_return1Shift(){
        Shift s1 = new Shift(LocalDate.of(2023, 1, 1).atTime(8,0),
                LocalDate.of(2023, 1, 1).atTime(10,0));
        List<Shift> shifts = new ArrayList<>();
        shifts.add(s1);
        List<Shift> result =  iShiftTimingCalculator.getMergedShifts(shifts);
        if(result.size() == 1){
            System.out.println("list size is 1");
        }
    }

}
