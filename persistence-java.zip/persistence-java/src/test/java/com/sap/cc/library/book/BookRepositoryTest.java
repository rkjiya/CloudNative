package com.sap.cc.library.book;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
public class BookRepositoryTest {
    private static final String HEAD_FIRST_JAVA = "Head First Java";
    private static final String HEAD_FIRST_NODE_JS = "Head First NodeJS";
    private static final String KATHY = "Kathy Sierra";
    private static final String CLEAN_CODE = "Clean Code" ;
    @Autowired
    private  BookRepository bookRepository;

    @Test
    public void  getAll_finAll_returnAllBooks(){
        List<Book> books = bookRepository.findAll();
        Assertions.assertThat(books).hasSizeGreaterThanOrEqualTo(0);
    }

    @Test
    public void saveABookAndReturnThat_findAll_resultShouldHaveSavedBook(){
        Book book = new Book();
        book.setTitle(HEAD_FIRST_JAVA);
        book.setAuthor(new Author(KATHY));
        Book savedBook = bookRepository.save(book);
        Assertions.assertThat(savedBook.getTitle()).isEqualTo(book.getTitle());
        Assertions.assertThat(savedBook.getAuthor().getName()).isEqualTo(KATHY);
    }

    @Test
    public void save2BooksWithDiffernetTitles_finaByTitle_resultShouldHaveBookWithTitle(){
        Book book1 = new Book();
        book1.setTitle(CLEAN_CODE);
        book1.setAuthor(new Author("John"));
        Book book2 = new Book();
        book2.setTitle(HEAD_FIRST_NODE_JS);
        book2.setAuthor(new Author("William"));
        bookRepository.saveAll(Arrays.asList(book1, book2));
        List<Book> returnedBooks = bookRepository.findByTitle(CLEAN_CODE);
        Assertions.assertThat(CollectionUtils.isEmpty(returnedBooks)).isEqualTo(false);
        Assertions.assertThat(returnedBooks.stream().filter(b -> CLEAN_CODE.equals(b.getTitle())).findAny().get()).isNotNull();
    }
}
