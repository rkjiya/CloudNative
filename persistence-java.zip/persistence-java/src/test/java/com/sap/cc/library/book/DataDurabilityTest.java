package com.sap.cc.library.book;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DataDurabilityTest {

    private static final String HEAD_FIRST_JAVASCRIPT = "Head First Javascript";
    private static final String HEAD_FIRST_SQL = "Head First SQL";
    private static final String HEAD_FIRST_JAVA = "Head First Java";
    @Autowired
    private BookRepository bookRepository;

    @Test
    public void populateDb(){
        Book java = new Book();
        java.setTitle(HEAD_FIRST_JAVA);
        Book sql = new Book();
        sql.setTitle(HEAD_FIRST_SQL);
        Book javascript = new Book();
        javascript.setTitle(HEAD_FIRST_JAVASCRIPT);
        List<Book> books = Arrays.asList(new Book(), new Book(), new Book());
        bookRepository.saveAll(books);
        List<Book> result = bookRepository.findAll();
        Assertions.assertThat(result).hasSizeGreaterThanOrEqualTo(3);
    }

    @Test
    public void isDbPopulated(){
        List<Book> result = bookRepository.findAll();
            Assertions.assertThat(result).hasSizeGreaterThanOrEqualTo(3);
    }
}
